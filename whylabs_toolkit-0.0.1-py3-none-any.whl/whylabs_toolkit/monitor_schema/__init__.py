# flake8: noqa
"""Top-level package for monitor-schema."""

from .models import Document

__author__ = """WhyLabs"""
__email__ = "monitor@whylabs.ai"
__version__ = "0.1.0"

__ALL__ = [
    Document,
]
